<?php

include "../config/conn.php";

$json = file_get_contents("php://input");

$obj = json_decode($json,true);

if(isset($obj['Precription']) && isset($obj['Specialist']) && isset($obj['Doctor']) && isset($obj['conditions']) && isset($obj['Suggestion']) ){


    $Precription = mysqli_real_escape_string($conn,$obj['Precription']);
    $Specialist = mysqli_real_escape_string($conn,$obj['Specialist']);  
    $Doctor = mysqli_real_escape_string($conn,$obj['Doctor']);
    $condition = mysqli_real_escape_string($conn,$obj['conditions']);
    $Suggestion = mysqli_real_escape_string($conn,$obj['Suggestion']);
   
     
    $sql="INSERT INTO edit_report(Precription,Specialist,Doctor,conditions,Suggestion) VALUES ('$Precription','$Specialist','$Doctor','$condition','$Suggestion')";

    $res=$conn->query($sql);
    
    
   

    echo json_encode($res);



  }
else{
    echo json_encode("connection failed");
}





?>