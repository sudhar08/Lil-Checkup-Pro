<?php

include '../config/conn.php';
$method = $_SERVER['REQUEST_METHOD'];

$result =[];


if ('POST' == $method) {
 
    $json = file_get_contents('php://input');
    $obj = json_decode($json,true);


        if(isset($obj["id"]) && isset($obj["name"]) && isset($obj["age"]) && isset($obj["phone_no"]) && isset($obj["base64Image"]) && isset($obj["location"]) && isset($obj["emailid"])){
       

        $id = mysqli_real_escape_string($conn,$obj['id']);
            $name = mysqli_real_escape_string($conn,$obj['name']);  
            $email = mysqli_real_escape_string($conn,$obj['emailid']);
            $age = mysqli_real_escape_string($conn,$obj['age']);
            $location = mysqli_real_escape_string($conn,$obj['location']);
            $phone_no = mysqli_real_escape_string($conn,$obj['phone_no']);
            $base64Image = $obj["base64Image"];



        $imageData = base64_decode($base64Image);
        $imageInfo = getimagesizefromstring($imageData);
        $mimeType = $imageInfo['mime'];
        
        if ($mimeType === 'image/jpeg') {
            $filenames =  $email. ".jpeg";
        } elseif ($mimeType === 'image/png') {
        $filenames =  $email. ".png";
        }
        elseif ($mimeType === 'image/jpg') {
            $filenames =  $email. ".jpg";
            }


        else {
            echo "Unknown image format";
        }
  
  $filePath = "../uploads/doctors_image/".$filenames;


  file_put_contents($filePath, $imageData);
  if(isset($filePath)){

    $sql="UPDATE doctors_detials SET doctor_name = '$name',age = '$age',location = '$location', email_id = '$email',phone_no = '$phone_no',image_path = '$filePath' WHERE id ='$id'";
    $res=$conn->query($sql);
    $result['status'] =true;
    $result['msg'] = 'successfully added';
    
    echo json_encode($result);
  }else{
    echo json_encode("upload the image in correct format  ");
  }
      
}
else{
    echo "json is corrupted";
}


}




?>