<?php

include '../config/conn.php';
$result =[];
$method = $_SERVER['REQUEST_METHOD'];
if ($method ==='POST'){
    $json = file_get_contents('php://input');
    $obj = json_decode($json,true);


    if(isset($obj["patient_id"])){
    $id = mysqli_real_escape_string($conn,$obj['patient_id']);
    $sql = "DELETE FROM add_child WHERE patient_id='$id'";
    $res=$conn->query($sql);
    $result['status'] =true;
    $result['msg'] = 'successfully added';
    
    }else{
        $result['status'] =false;
    $result['msg'] = 'unable to delete child';
    }
    echo json_encode($result);

}


?>