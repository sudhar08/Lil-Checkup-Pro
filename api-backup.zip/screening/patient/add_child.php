<?php

include "../config/conn.php";
$json = file_get_contents("php://input");

$obj = json_decode($json,true);

$result =[];

if(isset($obj['child_name']) && isset($obj['parent_name']) && isset($obj['dob']) && isset($obj['phone_no']) && isset($obj['weight']) && isset($obj['height']) && isset($obj['id']) && isset($obj['base64Image'])){

    $id = mysqli_real_escape_string($conn,$obj['id']);
    $child_name = mysqli_real_escape_string($conn,$obj['child_name']);
    $parent_name = mysqli_real_escape_string($conn,$obj['parent_name']);
    $dob = mysqli_real_escape_string($conn,$obj['dob']);
    $phone_no = mysqli_real_escape_string($conn,$obj['phone_no']);
    $weight = mysqli_real_escape_string($conn,$obj['weight']);
    $height = mysqli_real_escape_string($conn,$obj['height']);
    $base64Image = $obj["base64Image"];
  
      // Decode the Base64 data
      $imageData = base64_decode($base64Image);
      $imageInfo = getimagesizefromstring($imageData);
      $mimeType = $imageInfo['mime'];
      
      if ($mimeType === 'image/jpeg') {
        $filename =  $child_name. ".jpeg";
    } elseif ($mimeType === 'image/png') {
      $filename =  $child_name. ".png";
    }  else {
        echo "Unknown image format";
    }
      
      $filePath = "../uploads/patient_image/".$filename;
  
    
      file_put_contents($filePath, $imageData);
  
      
if(isset($filePath)){

    $sql="INSERT INTO add_child (id,child_name,parent_name,dob,phone_no,weight,height,image_path) VALUES ('$id','$child_name','$parent_name','$dob','$phone_no','$weight','$height','$filePath')";
    $res=$conn->query($sql);
    $result['status'] =true;
    $result['msg'] = 'successfully added';
    
    echo json_encode($result);
  }else{
    echo json_encode("upload the image in correct format  ");
  }


}
else{
    echo json_encode("connection failed");
}

?>
