<?php
include'conn.php';
$target_dir = "../uploads/audio/"; // Directory to store uploaded files
$allowed_extensions = array("mp3", "wav", "ogg"); // Allowed file extensions

// Check if a file was uploaded
if (isset($_FILES["audio_file"]["name"])) {

    // Get file information
    $filename = $_FILES["audio_file"]["name"];
    $filesize = $_FILES["audio_file"]["size"];
    $temp_name = $_FILES["audio_file"]["tmp_name"];
    $error = $_FILES["audio_file"]["error"];

    // Check for errors
    if ($error !== UPLOAD_ERR_OK) {
        echo "Error uploading file: " . $error;
    } else {

        // Check file extension
        $file_ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (!in_array($file_ext, $allowed_extensions)) {
            echo "Invalid file type. Only " . implode(', ', $allowed_extensions) . " allowed.";
        } else {

            // Check file size
            if ($filesize > 5000000) { // 5MB limit
                echo "File size exceeds limit.";
            } else {

                // Generate a unique file name
                $new_filename = uniqid() . "." . $file_ext;

                // Move the uploaded file to the target directory
                if (move_uploaded_file($temp_name, $target_dir . $new_filename)) {
                    echo "File uploaded successfully.";
                } else {
                    echo "Error moving uploaded file.";
                }
            }
        }
    }
} else {
    echo "No file selected.";
}

?>