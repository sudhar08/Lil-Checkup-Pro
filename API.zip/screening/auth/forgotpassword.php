<?php 
  include "../config/conn.php";
  
  //Received JSON into $json variable
  $json = file_get_contents('php://input');
  
  //Decoding the received JSON and store into $obj variable.
  $obj = json_decode($json,true);
  
  if(isset($obj["email"]) && isset($obj["password"])){
    
    $email = mysqli_real_escape_string($conn,$obj['email']);
    $pwd = mysqli_real_escape_string($conn,$obj['password']);
    
    //Declare array variable
    $result=[];
    try{
    //Select Query
    $sql="UPDATE login_user SET password='{$pwd}' WHERE email_id='{$email}'";
    $res=$conn->query($sql);
      $result['Status']=true;

      $result['message']="updated sucessfully.";
     

      
     

    }catch(mysqli_sql_exception $e) {
      $result['loginStatus']=false;

      $result['message']="Invalid Login Details";

      
    
    }
    
    // Converting the array into JSON format.
    $json_data=json_encode($result);
   
    
   
    // Echo the $json.
    echo $json_data;
   
  }
?>