<?php
include '../config/conn.php';

// Error handling
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$result = [];
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    // Read and decode JSON data
    $json = file_get_contents("php://input");
    $obj = json_decode($json, true);
    
    $pattern = "/\[|\]/";

    // Validate and sanitize data
    $id = filter_var($obj['id'], FILTER_SANITIZE_NUMBER_INT);
    $patient_id = filter_var($obj['patient_id'], FILTER_SANITIZE_NUMBER_INT);
    $condition = filter_var($obj['conditions'], FILTER_SANITIZE_STRING);
    $behaviour = filter_var($obj['updater_conditions'], FILTER_SANITIZE_STRING);
    
    $condition = preg_replace($pattern,"",$condition);

    // Prepare SQL statement
    $sql = "UPDATE patient_table SET conditions = ? , completed_Behaviour = ?  WHERE patient_id = ?";
    $stmt = $conn->prepare($sql);

    // Bind parameters and execute
    $stmt->bind_param('ssi', $condition, $behaviour, $patient_id);
    $stmt->execute();

    // Check for errors
    if ($stmt->error) {
        $result['status'] = false;
        $result['msg'] = "Error updating: " . $stmt->error;
    } else {
        $result['status'] = true;
        $result['msg'] = "Successfully updated";
    }

    // Close statement
    $stmt->close();
}

echo json_encode($result);

// Close connection
mysqli_close($conn);
