<?php
// if (isset($_POST['base64Image'])) {

// $base64Image = $_POST['base64Image'];
//  $decodedImage = base64_decode($base64Image);

//  $filename = $decodedImage['name'];
//   $tmp_name = $decodedimage['tmp_name'];
//   $error = $decodedImage['error'];
//   $size = $decodedImage['size'];

//   if ($error === UPLOAD_ERR_OK) {
//     $destination = 'uploads/' . $filename;
//     if (move_uploaded_file($tmp_name, $destination)) {
//       echo "Image uploaded successfully";
//     } else {
//       echo "Failed to upload image";
//     }
//   } else {
//     echo "An error occurred while uploading the image";
//   }
// }




if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the Base64-encoded image data from the form
    if (isset($_POST["base64Image"])) {
    $base64Image = $_POST["base64Image"];

    // Decode the Base64 data
    $imageData = base64_decode($base64Image);

    // Generate a unique filename (you can use other logic to create a unique name)
    $filename = uniqid() . ".jpg";

    // Specify the path where you want to store the image
    $filePath = "uploads/" . $filename;

    // Save the image to the specified path
    file_put_contents($filePath, $imageData);

    echo "Image uploaded successfully!";
    }
    else{
        echo "image not sucessfull!";
    }

}

 else {
    echo "Invalid request.";
}

?>

