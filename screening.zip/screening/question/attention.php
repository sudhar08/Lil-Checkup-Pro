<?php
 include "../config/conn.php";

$result = [];


$sql="SELECT * FROM attention";
$res=$conn->query($sql);


if($res->num_rows>0){
  $row = mysqli_fetch_all($res,MYSQLI_ASSOC);
    
    $q= [];
    
    array_push($q,$row);
    

$result['Status']=true;
    $result['message']="Successfully the id retrived from the database.";
    $result["questions"]=$q;
    
  }else{
    
    $result['Status']=false;
    $result['message']="failed to retrieve the id from the database";
    $result['userInfo']="failed to retrieve the id from the database";
  }
 
 $json_data=json_encode( $result['questions']);
  
 echo $json_data;



?>