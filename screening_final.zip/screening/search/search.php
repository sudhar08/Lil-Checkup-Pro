<?php
include '../config/conn.php';

// Error handling
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$result =[];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Get the search keyword from the form
  $search_keyword = $_POST["search"];

  // Prepare a SQL query to search for the keyword in the database table
  $sql = "SELECT * FROM patient_table WHERE child_name LIKE '%$search_keyword%'";

  // Execute the query
  $res = $conn->query($sql);

  if ($res->num_rows > 0) {
    $row = mysqli_fetch_assoc($res);
    
   
    
    
    $result['ouput']= $row;
    echo json_encode( $result);
  } else {
    echo "No results found";
  }
}
?>