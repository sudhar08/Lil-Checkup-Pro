<?php

include "../config/conn.php";
$json = file_get_contents("php://input");

$obj = json_decode($json, true);

$result = [];

if (isset($obj['child_name']) && isset($obj['parent_name']) && isset($obj['dob']) && isset($obj['phone_no']) && isset($obj['weight']) && isset($obj['height']) && isset($obj['id']) && isset($obj['base64Image'])) {

    $id = mysqli_real_escape_string($conn, $obj['id']);
    $child_name = mysqli_real_escape_string($conn, $obj['child_name']);
    $parent_name = mysqli_real_escape_string($conn, $obj['parent_name']);
    $dob = mysqli_real_escape_string($conn, $obj['dob']);
    $phone_no = mysqli_real_escape_string($conn, $obj['phone_no']);
    $weight = mysqli_real_escape_string($conn, $obj['weight']);
    $height = mysqli_real_escape_string($conn, $obj['height']);
    $base64Image = $obj["base64Image"];

    // Decode the Base64 data
    $imageData = base64_decode($base64Image);
    $imageInfo = getimagesizefromstring($imageData);
    
    // Check if getimagesizefromstring returned false
    if ($imageInfo === false) {
        echo json_encode(["status" => false, "msg" => "Invalid image data"]);
        exit;
    }

    $mimeType = $imageInfo['mime'];
    $number = rand(100, 100000);
    $generateFilename = (string)$number . $child_name . $phone_no;

    if (!empty($base64Image)) {
        if ($mimeType === 'image/jpeg') {
            $filenames = $generateFilename . ".jpeg"; // Use a unique identifier like $id
        } elseif ($mimeType === 'image/png') {
            $filenames = $generateFilename . ".png";
        } elseif ($mimeType === 'image/jpg') {
            $filenames = $generateFilename . ".jpg";
        } else {
            echo json_encode(["status" => false, "msg" => "Unknown image format"]);
            exit;
        }

        $filePath = "../uploads/patient_image/" . $filenames;
        if (file_put_contents($filePath, $imageData) === false) {
            echo json_encode(["status" => false, "msg" => "Failed to save image"]);
            exit;
        }
    }

    if (isset($filePath)) {
        $sql = "INSERT INTO add_child (id, child_name, parent_name, dob, phone_no, weight, height, image_path) VALUES ('$id', '$child_name', '$parent_name', '$dob', '$phone_no', '$weight', '$height', '$filePath')";
        $res = $conn->query($sql);
        
        if ($res) {
            $result['status'] = true;
            $result['msg'] = 'Successfully added';
        } else {
            $result['status'] = false;
            $result['msg'] = 'Failed to add record to database';
        }

        echo json_encode($result);
    } else {
        echo json_encode(["status" => false, "msg" => "Upload the image in correct format"]);
    }
} else {
    echo json_encode(["status" => false, "msg" => "Missing required fields"]);
}

?>
