<?php
 include "../config/conn.php";
$json = file_get_contents('php://input');
$obj = json_decode($json,true);
  
if(isset($obj["username"]) && isset($obj["passwords"])  && isset($obj["emailid"]) && isset($obj["registrationno"]) && isset($obj["id"])&& isset($obj["phone_no"])){



  $id = mysqli_real_escape_string($conn,$obj['id']);
  $username = mysqli_real_escape_string($conn,$obj['username']);  
  $password = mysqli_real_escape_string($conn,$obj['passwords']);
  $email = mysqli_real_escape_string($conn,$obj['emailid']);
  $registrtion = mysqli_real_escape_string($conn,$obj['registrationno']);
  $phone_no = mysqli_real_escape_string($conn,$obj['phone_no']);

  $hashed_password = password_hash($password,PASSWORD_DEFAULT);

  $sql="INSERT INTO register_user (id,name,email_id,registration_no,phone_no,password) VALUES ('$id','$username', '$email', '$registrtion','$phone_no', '$password')";
  $res=$conn->query($sql);
  echo json_encode("successfully added");
}
else{
    echo json_encode('failed');
}  

?>