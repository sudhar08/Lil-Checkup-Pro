<?php

include "../config/conn.php";
// Initialize error messages
$error = "";
$success = "";

// Check if the request method is POST and content type is JSON
if ($_SERVER["REQUEST_METHOD"] == "POST" ) {
    // Read the raw POST data (the JSON input)
    $json = file_get_contents('php://input');

    // Decode the JSON data into a PHP associative array
    $data = json_decode($json, true);

    // Get the submitted data from the JSON array
    $email = $data['emailid'];
    $password = $data['password'];

    // Check if the email and password fields are not empty
    if (!empty($email) && !empty($password)) {
        // Prepare the SQL query to fetch the password for the given email
        $sql = "SELECT password FROM  register_user  WHERE email_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($stored_password);
        $stmt->fetch();
        $stmt->close();

        // Verify if the provided password matches the stored password
        if ($stored_password === $password) {
            // Prepare the SQL query to delete the account
            $sql = "DELETE FROM  register_user  WHERE email_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $email);

            // Execute the deletion
            if ($stmt->execute()) {
                $success = "Account deleted successfully!";
                echo json_encode(["success" => true, "message" => $success]);
            } else {
                $error = "Error deleting account. Please try again.";
                echo json_encode(["success" => false, "message" => $error]);
            }

            $stmt->close();
        } else {
            $error = "Incorrect email or password!";
            echo json_encode(["success" => false, "message" => $error]);
        }
    } else {
        $error = "Email and password are required!";
        echo json_encode(["success" => false, "message" => $error]);
    }
}

// Close the database connection
$conn->close();


?>

