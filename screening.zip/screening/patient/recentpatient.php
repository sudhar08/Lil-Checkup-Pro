<?php

// Include the connection file
require '../config/conn.php';

// Initialize an empty response array
$result = [];

// Read and decode the JSON data from the client
$json = file_get_contents('php://input');
$obj = json_decode($json, true);

if (isset($obj["id"])) {

    // Sanitize the user ID using mysqli_real_escape_string
    $id = mysqli_real_escape_string($conn, $obj['id']);

    
    $sql = "SELECT * FROM add_child WHERE id = ? ORDER BY patient_id  DESC";

    // Create a prepared statement
    $stmt = $conn->prepare($sql);

    // Bind the user ID parameter to the prepared statement
    $stmt->bind_param("s", $id);

    // Execute the prepared statement
    if ($stmt->execute()) {

        // Fetch all results as associative arrays
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

        if ($rows) {
            $result['Status'] = true;
            $result['message'] = "Successfully retrieved the recently added patient list.";
            $result['pateintinfo'] = $rows;
        } else {
            $result['Status'] = false;
            $result['message'] = "No recently added patients found for the provided user.";
        }
    } else {
        $result['Status'] = false;
        $result['message'] = "Error executing the query: " . $stmt->error;
    }

    // Close the prepared statement
    $stmt->close();

} else {
    // Handle missing user ID
    $result['Status'] = false;
    $result['message'] = "Missing required 'user_id' parameter in the request.";
}

// Encode the response data as JSON
$json_data = json_encode($result);

// Echo the JSON response
echo $json_data;

// Close the database connection (if needed)
$conn->close();

?>
