<?php

include '../config/conn.php';



$method = $_SERVER['REQUEST_METHOD'];
if ('POST' == $method) {
$rawData = file_get_contents("php://input");

// Decode the JSON input
$data = json_decode($rawData, true);

// Initialize error and success messages
$error = "";
$success = "";

// Check if JSON input is valid and contains required fields
if (isset($data['emailid']) && isset($data['old_password']) && isset($data['new_password'])) {
    // Get the submitted form data from JSON
    $email = $data['emailid'];
    $old_password = $data['old_password'];
    $new_password = $data['new_password'];

    // Check if the email, old password, and new password fields are not empty
    if (!empty($email) && !empty($old_password) && !empty($new_password)) {
        // Fetch the current password from the database
        $sql = "SELECT password FROM login_user WHERE email_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($stored_password);
        $stmt->fetch();
        $stmt->close();

        // Verify the old password
        if ($stored_password === $old_password) {
            // Update the password in the database
            $sql = "UPDATE login_user SET password = ? WHERE email_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $new_password, $email);

            if ($stmt->execute()) {
                // Return a success message as JSON
                $success = "Password changed successfully!";
                echo json_encode(["success" => true, "message" => $success]);
            } else {
                // Return an error message as JSON
                $error = "Error updating password. Please try again.";
                echo json_encode(["success" => false, "message" => $error]);
            }

            $stmt->close();
        } else {
            // Return an error message if old password is incorrect
            $error = "Old password is incorrect!";
            echo json_encode(["success" => false, "message" => $error]);
        }
    } else {
        // Return an error message if any field is empty
        $error = "All fields are required!";
        echo json_encode(["success" => false, "message" => $error]);
    }
} else {
    // Return an error message if the JSON is invalid or missing fields
    $error = "Invalid input data. Please provide emailid, old_password, and new_password.";
    echo json_encode(["success" => false, "message" => $error]);
}
}else{
    // Return an error message if the JSON is invalid or missing fields
    $error = "Invalid resquest method.";
    echo json_encode(["success" => false, "message" => $error]);

}
$conn->close();

?>


